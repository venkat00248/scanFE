/* eslint-disable @typescript-eslint/no-explicit-any */

import { Onboarding } from "../payment/Onboarding"

export const EditTenant = ({item}:any) => {

    console.log("item,", item)
  return (
    <div>
      <Onboarding/>
    </div>
  )
}
