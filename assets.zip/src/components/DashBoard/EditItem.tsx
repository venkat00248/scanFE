/* eslint-disable @typescript-eslint/no-explicit-any */

import { Items } from "../Items/Items"

export const EditItem = ({item}:any) => {

    console.log("item,", item)
  return (
    <div>
      <Items/>
    </div>
  )
}
