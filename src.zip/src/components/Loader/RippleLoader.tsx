import './RippleLoader.scss'
export const RippleLoader = () => {
  return (
    <div className='RippleWrapper'>
    <div className="ripples-div"></div>
    </div>
  )
}
