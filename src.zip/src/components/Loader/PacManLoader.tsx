import './PacManLoader.scss'
export const PacManLoader = () => {
  return (
    <div className='PMWrapper'>
    <div className="pac-man"></div>
    </div>
  )
}
